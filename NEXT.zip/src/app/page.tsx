"use client"

export default function Home() {
    return (
        <div className="p-2 h-[85%] grid grid-rows-2">

                <div className="grid grid-cols-2">
                    
                    <div className="grid grid-flow-col grid-rows-8 bg-green-200">
                        <div className="row-span-2 bg-red-200">
                            
                        </div>
                        <div className="row-span-6 bg-blue-200"></div>
                    </div>

                    <div className="bg-violet-200"></div>
                </div>
                
            
            <div className="overflow-hidden"></div>
        </div>
    )
}
